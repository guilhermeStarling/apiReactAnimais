import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import Routes from './route.jsx'

function App() {
  return (
    <Routes/>
  );
}

export default App;
